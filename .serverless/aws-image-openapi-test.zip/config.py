class Config:
    AWS_ACCESS_KEY_ID = 'AKIAQMNKTFMG4N7QGE6Q'
    AWS_SECRET_ACCESS_KEY = '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'

    S3_BUCKET = 'wnstjq-img-test'
    S3_BASE_URL = 'https://' + S3_BUCKET + '.s3.amazonaws.com/'

    X_NAVER_CLIENT_ID = 'hIAwNMp9hxuqdI5DfR80'
    X_NAVER_CLIENT_SECRET = 'Zlhiz6ph_k'